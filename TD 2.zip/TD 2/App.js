import React from "react";
import Pictogramme from "./Pictogramme";
import Commentaire from "./Commentaire";
import 'font-awesome/css/font-awesome.min.css';
import Star from "./Star";

class App extends React.Component {





 




  render() {
    

     
    return (

      <div style={{display : "flex",width:"120px",height:"120px"}} >
        
        <Star/>

        <Star/>
        <Star/>
        <Star/>
        <Star/>
        <Star/>

        
    
        
      </div>
 




    )
  }
}
export default App;
